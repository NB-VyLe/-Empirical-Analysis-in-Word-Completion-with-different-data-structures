from dictionary.base_dictionary import BaseDictionary
from dictionary.word_frequency import WordFrequency
import typing

# ------------------------------------------------------------------------
# This class is required TO BE IMPLEMENTED. Hash-table-based dictionary.
#
# __author__ = 'Son Hoang Dau'
# __copyright__ = 'Copyright 2022, RMIT University'
# ------------------------------------------------------------------------

class HashTableDictionary(BaseDictionary):

    def build_dictionary(self, words_frequencies: [WordFrequency]):
        """
        construct the data structure to store nodes
        @param words_frequencies: list of (word, frequency) to be stored
        """
        # TO BE IMPLEMENTED
        self.dictionary = {}
        for word_frequency in words_frequencies:
            self.dictionary[word_frequency.word] = word_frequency.frequency

    def search(self, word: str) -> int:
        """
        search for a word
        @param word: the word to be searched
        @return: frequency > 0 if found and 0 if NOT found
        """
        # TO BE IMPLEMENTED
        # place holder for return

        frequency = 0 # base case
        if word in self.dictionary: # if exists
            frequency = self.dictionary[word] # get frequency
        return frequency

    def add_word_frequency(self, word_frequency: WordFrequency) -> bool:
        """
        add a word and its frequency to the dictionary
        @param word_frequency: (word, frequency) to be added
        :return: True whether succeeded, False when word is already in the dictionary
        """
        # TO BE IMPLEMENTED
        # place holder for return
        success = False
        if self.search(word_frequency.word) == 0: # if not already in dict
            self.dictionary[word_frequency.word] = word_frequency.frequency # add to dict
            success = True # update status

        return success

    def delete_word(self, word: str) -> bool:
        """
        delete a word from the dictionary
        @param word: word to be deleted
        @return: whether succeeded, e.g. return False when point not found
        """
        # TO BE IMPLEMENTED
        # place holder for return
        success = False
        if int(self.search(word)) > 0: # If eexists
            del self.dictionary[word]
            success = True

        return success

    def autocomplete(self, prefix_word: str) -> [WordFrequency]:
        """
        return a list of 3 most-frequent words in the dictionary that have 'word' as a prefix
        @param word: word to be autocompleted
        @return: a list (could be empty) of (at most) 3 most-frequent words with prefix 'word'
        """
        # TO BE IMPLEMENTED
        # place holder for return

        
        matches = [] # Create empty dict of matches

        for word, frequency in self.dictionary.items(): # Iter through instance's dictionary
            if word.startswith(prefix_word): # if entry's word starts with given prefix
                matches.append(WordFrequency(word, frequency)) # add to our created matches dict
        
        sorted_matches = sorted(matches, key= lambda x:x.frequency, reverse=True)

        if len(matches) >= 3:
            top_matches = sorted_matches[:3] # Sort by value - 'matches.get', then return top 3 using slicing
        else:
            top_matches = sorted_matches

        return top_matches
