from dictionary.word_frequency import WordFrequency
from dictionary.base_dictionary import BaseDictionary

# ------------------------------------------------------------------------
# This class is required TO BE IMPLEMENTED. List-based dictionary implementation.
#
# __author__ = 'Son Hoang Dau'
# __copyright__ = 'Copyright 2022, RMIT University'
# ------------------------------------------------------------------------

class ListDictionary(BaseDictionary):

    def build_dictionary(self, words_frequencies: [WordFrequency]):
        """
        construct the data structure to store nodes
        @param words_frequencies: list of (word, frequency) to be stored
        """
        self.dictionary = words_frequencies # Python uses "dict" so naming our attribute as "dictionary" should not cause any conflict

        # self.dictionary = []
        # for word_frequency in words_frequencies:
        #     self.dictionary.append(word_frequency)

    def search(self, word: str) -> int:
        """
        search for a word
        @param word: the word to be searched
        @return: frequency > 0 if found and 0 if NOT found
        """
        # TO BE IMPLEMENTED
        # place holder for return

        frequency = 0 # base case

        for entry in self.dictionary: # Iterate through instance's dictionary
            if entry.word == word: # if word in dictionary element is equal to word that we parsed in
                frequency = entry.frequency # update frequency variable to word's frequency (the word we found in our instance's dicitionary)

        return frequency

    def add_word_frequency(self, word_frequency: WordFrequency) -> bool:
        """
        add a word and its frequency to the dictionary
        @param word_frequency: (word, frequency) to be added
        :return: True whether succeeded, False when word is already in the dictionary
        """

        # TO BE IMPLEMENTED
        # place holder for return

        success = False # base case

        if self.search(word_frequency.word) == 0: # Check if not already in dictionary
            self.dictionary.append(word_frequency)
            success = True
        # TODO: elif duplicate found, increment frequency ???

        return success

    def delete_word(self, word: str) -> bool:
        """
        delete a word from the dictionary
        @param word: word to be deleted
        @return: whether succeeded, e.g. return False when point not found
        """
        # TO BE IMPLEMENTED
        # place holder for return
        success = False

        for entry in self.dictionary: # iter through instance's dictionary
            if entry.word == word: # if found
                self.dictionary.remove(entry) # remove
                success = True # update return variable

        return success

    def autocomplete(self, prefix_word: str) -> [WordFrequency]:
        """
        return a list of 3 most-frequent words in the dictionary that have 'prefix_word' as a prefix
        @param prefix_word: word to be autocompleted
        @return: a list (could be empty) of (at most) 3 most-frequent words with prefix 'prefix_word'
        """
        # TO BE IMPLEMENTED
        # place holder for return

        matches = [] # Create empty dict of matches

        for entry in self.dictionary: # Iter through instance's dictionary
            if entry.word.startswith(prefix_word): # if entry's word starts with given prefix
                matches.append(entry)
        
        sorted_matches = sorted(matches, key= lambda x:x.frequency, reverse=True)

        if len(matches) >= 3:
            top_matches = sorted_matches[:3] # Sort by value - 'matches.get', then return top 3 using slicing
        else:
            top_matches = sorted_matches

        return top_matches
