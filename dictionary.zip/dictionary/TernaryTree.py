from .node import Node

class TernaryTree:
    def __init__(self):
        self.root = None

    def insert(self, letter, frequency):
        self.root = self._insert_recursive(self.root, letter, 0, frequency)

    def _insert_recursive(self, root, letter, count, frequency):
        single_letter = letter[count]

        # If empty
        if not root:
            root = Node(single_letter)

        if single_letter < root.letter:
            root.left = self._insert_recursive(root.left, letter, count, frequency)
        elif single_letter > root.letter:
            root.right = self._insert_recursive(root.right, letter, count, frequency)
        elif count < len(letter) - 1:
            root.middle = self._insert_recursive(root.middle, letter, count+1, frequency)
        else:
            root.end_word = True
            root.frequency = frequency

        return root

    def search(self, letter):
        return self._search_recursive(self.root, letter, 0)

    def _search_recursive(self, root, letter, count):

        if root is None:
            return None
        single_letter = letter[count]
        
        if single_letter < root.letter:
            return self._search_recursive(root.left, letter, count)
       
        elif single_letter > root.letter:
            return self._search_recursive(root.right, letter, count)
        elif count < len(letter) - 1:
            return self._search_recursive(root.middle, letter, count+1)

     
        
        # print(root.letter)
        return root.frequency

    def delete(self, letter):
        return self._delete_recursive(self.root, letter, 0)

    def _delete_recursive(self, root, letter, count):
        if root is None:
            return None
        single_letter = letter[count]

        if single_letter < root.letter:
            return self._delete_recursive(root.left, letter, count)
        elif single_letter > root.letter:
            return self._delete_recursive(root.right, letter, count)
        elif count < len(letter) - 1:
            return self._delete_recursive(root.middle, letter, count+1)
    
        root.end_word = False
        root.frequency = 0
        return True

    def traverse(self):
        self.traversal = []
        result = [None] * 50 # Creating empty array with capacity of 50
        self._traverse_recursive(self.root, result, 0)
        return self.traversal

    def _traverse_recursive(self, root, result, depth):
        if root:
            # LEFT
            self._traverse_recursive(root.left, result, depth)

            # GET RESULT
            result[depth] = root.letter
            if root.end_word:
                result[depth+1] = '\0' # \0 is our separator, so we know where to slice

                result_word = list(filter(None, result)) # Remove empty/None elements from our array
                word = (''.join(result_word).split('\0')[0]) # 1) make new array using our filtered result array 2) split using our separator 3) then get first element
                self.traversal.append(word) # 


            # MIDDLE
            self._traverse_recursive(root.middle, result, depth+1)
            # RIGHT
            self._traverse_recursive(root.right, result, depth)
        return result

