from funcs import *
import pandas as pd
import numpy as np

# path = input("Enter the path to the dataset file: ")
path = "sampleData200k.txt"

wf_array = get_wordfrequencies(path)

if wf_array:
    print("\n   WordFrequency Array built. Creating framework...\n")

    start_values = [2000,5000,10000,20000,30000,40000,50000]
    incr_percent = 0.10

    subset_1 = TestFrameWork(wf_array=wf_array[:60000], starts=start_values, incr=incr_percent)
    subset_2 = TestFrameWork(wf_array=wf_array[60000:120000], starts=start_values, incr=incr_percent)
    subset_3 = TestFrameWork(wf_array=wf_array[120000:180000], starts=start_values, incr=incr_percent)
    print("     Done!")

    # static analysis
    print(subset_1.static_analysis("hashtable", 5000)[0])
else:
    print("Error creating WordFrequency Array")

