from ..dictionary.word_frequency import WordFrequency
from ..dictionary.list_dictionary import ListDictionary
from ..dictionary.hashtable_dictionary import HashTableDictionary
from ..dictionary.ternarysearchtree_dictionary import TernarySearchTreeDictionary
import time
import random

class TestFrameWork:
    def __init__(self, wf_array: list[WordFrequency], starts: list[int], incr:float):
        self.wf_array = wf_array # Array of WordFrequency objects
        self.starts = starts
        self.incr = incr # Percentage of dict to add/remove

    def grow_analysis(self, impl: str):
        used_dict = self._get_dict(impl)

        avg_times = {start:0 for start in self.starts} # keys of increment, default vlaue of 0 (we will add later)


        for start in self.starts:
            used_dict.build_dictionary(self.wf_array[:start])


            each_times = [] # store all times for each add operation

            runs = int(self.incr * start)

            for wf in self.wf_array[start:start+runs]:
                time_begin = time.time()
                used_dict.add_word_frequency(wf)
                time_end = time.time()
                time_taken = time_end - time_begin
                each_times.append(time_taken)

            avg_time = sum(each_times) / len(each_times)
            avg_times[start] = avg_time

        return avg_times

    def shrink_analysis(self, impl: str):
        used_dict = self._get_dict(impl)

        avg_times = {start:0 for start in self.starts} # keys of increment, default vlaue of 0 (we will add later)


        for start in self.starts:
            used_dict.build_dictionary(self.wf_array[:start])


            each_times = [] # store all times for each add operation

            runs = int(self.incr * start)

            for wf in self.wf_array[start-runs:start]:
                time_begin = time.time()
                used_dict.delete_word(wf.word)
                time_end = time.time()
                time_taken = time_end - time_begin
                each_times.append(time_taken)

            avg_time = sum(each_times) / len(each_times)
            avg_times[start] = avg_time

        return avg_times

    def static_analysis(self, impl: str, runs:int):

        sizes = [int(len(self.wf_array)/3), int(len(self.wf_array)/2), int(len(self.wf_array))] # Split to small, medium, large
        sizes_names = ["Small", "Medium", "Large"]

        avg_search_times = {size_name:0 for size_name in sizes_names} # keys of increment, default vlaue of 0 (we will add later)
        avg_autocomplete_times = {size_name:0 for size_name in sizes_names} # keys of increment, default vlaue of 0 (we will add later)

        for size, size_name in zip(sizes, sizes_names):
            search_times = []
            autocomplete_times = []
            used_dict = self._get_dict(impl)
            used_dict.build_dictionary(self.wf_array[:size])

            run_count = 0
            while run_count < runs:
                word_to_use = (random.choice(self.wf_array)).word
                prefix = word_to_use[:2] # Use first 2 letters as prefix                

                # SEARCH
                time_begin = time.time()

                used_dict.search(word_to_use)

                time_end = time.time()
                time_taken = time_end - time_begin
                search_times.append(time_taken)

                # AUTOCOMPLETE
                time_begin = time.time()

                used_dict.autocomplete(prefix)

                time_end = time.time()
                time_taken = time_end - time_begin
                autocomplete_times.append(time_taken)

                # increment run count
                run_count += 1

            avg_search_time = sum(search_times) / len(search_times)
            avg_autocomplete_time = sum(autocomplete_times) / len(autocomplete_times)

            avg_search_times[size_name] = avg_search_time
            avg_autocomplete_times[size_name] = avg_autocomplete_time

        return avg_search_times, avg_autocomplete_times


    # Helper function used by all functions above. Made to prevent D.R.Y.
    def _get_dict(self, impl: str):
        used_dict = None # base case
        if impl == "list":
            used_dict = ListDictionary()
        elif impl == "hashtable":
            used_dict = HashTableDictionary()
        elif impl == "tst":
            used_dict = TernarySearchTreeDictionary()
        else:
            print("Incorrect Dictionary type specified.\n Must be 'list', 'hashtable', or 'tst'.")
        return used_dict

def get_wordfrequencies(path):
    wf_array = []

    with open(path, 'r') as f:
        for line in f:
            row = line.split("  ")
            word = row[0]
            frequency = row[1]
            wf = WordFrequency (word, frequency)
            wf_array.append(wf)

    return wf_array

